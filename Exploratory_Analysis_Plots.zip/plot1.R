source("sccData.R")

library(dplyr)


values<- NEI %>% group_by(year) %>% summarise(sum =sum(Emissions, na.rm = T))
png(filename = "plot1.png")


barplot(values$sum, names.arg =  values$year,ylab = "PM2.5 Total Emissions", xlab = "Year", main = "PM 2.5 Emissions trend 1999-2008")

dev.off()

