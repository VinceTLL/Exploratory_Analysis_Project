
source("sccData.R")

png(filename = "plot2.png")

BaltiEmissions<- NEI %>% filter( fips == "24510") %>% group_by(year) %>% summarise( sum = sum(Emissions,na.rm = T))

with(BaltiEmissions,barplot(sum, names.arg = year,ylab = "PM2.5 Total Emissions", xlab = "Year",main = "PM 2.5 Emissions trend Balitimore City 1999-2008"))


dev.off()


