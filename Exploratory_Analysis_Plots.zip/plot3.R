source("sccData.R")

library(ggplot2)
library(dplyr)

png(filename = "plot3.png")



sources<- NEI %>% filter(fips == "24510") %>%  group_by(year,type) %>% summarise(sum = sum(Emissions, na.rm = T))

ggplot(sources)  + geom_bar(aes(x = as.factor(year),weight = sum) )  + facet_grid(as.factor(type)~.) +
  labs(y = "PM2.5 total EMissions", title = "pm 2.5 Emissions trend by sources in Baltimore City, 1999-2008", x ="year") + 
  theme(plot.title = element_text(hjust = 0.5))

dev.off()