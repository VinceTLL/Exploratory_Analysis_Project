source("sccData.R")

library(ggplot2)
library(dplyr)





tb1<- NEI %>% select(NEI_SCC = SCC,year,Emissions,fips)
tb2<- SCC %>% select(SCC_SCC = SCC,EI.Sector)
final_tb <- inner_join(tb1,tb2,by = c("NEI_SCC" = "SCC_SCC"))

coal_comb<- final_tb %>% 
  filter(EI.Sector == "Fuel Comb - Electric Generation - Coal" | EI.Sector =="Fuel Comb - Comm/Institutional - Coal" | EI.Sector == "Fuel Comb - Industrial Boilers, ICEs - Coal") %>%
  group_by(year) %>% summarise(sum = sum(Emissions,na.rm = T))
coal_comb<- transform(coal_comb,year =factor(year))

png(filename = "plot4.png")

ggplot(coal_comb)  + geom_bar(aes(x = year, weight =sum)) +
  labs(y = "PM2.5 Total Emissions value", title = "PM2.5 Total Emiss.from coal combustion-related source, 1999-2008") 
dev.off()