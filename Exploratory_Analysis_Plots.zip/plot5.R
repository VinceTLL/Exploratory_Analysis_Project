
source("sccData.R")

library(ggplot2)
library(dplyr)



tb1<- NEI %>% select(NEI_SCC = SCC,year,Emissions,fips)
tb2<- SCC %>% select(SCC_SCC = SCC,EI.Sector)
final_tb <- inner_join(tb1,tb2,by = c("NEI_SCC" = "SCC_SCC"))

motor<- final_tb %>% 
  filter(fips == "24510" & EI.Sector %in% c("Mobile - Aircraft","Mobile - Commercial Marine Vessels","Mobile - Locomotives","Mobile - Non-Road Equipment - Diesel","Mobile - Non-Road Equipment - Gasoline","Mobile - Non-Road Equipment - Other","Mobile - On-Road Diesel Heavy Duty Vehicles","Mobile - On-Road Diesel Light Duty Vehicles","Mobile - On-Road Gasoline Heavy Duty Vehicles","Mobile - On-Road Gasoline Light Duty Vehicles")) %>% 
  group_by(year) %>% summarise(sum= sum(Emissions,na.rm = T))

                               
png(filename = "plot5.png")

ggplot(motor)  + geom_bar(aes(x = as.factor(year),weight = sum),size = 1.5 ) +
  labs(y = "PM2.5 total emissions", title = "PM2.5 total emiss. motor vehicle sources,Baltimore City, 1999-2008", x = "year") + theme(plot.title = element_text(hjust = 0.5))
dev.off()