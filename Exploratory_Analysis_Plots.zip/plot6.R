source("sccData.R")

library(ggplot2)
library(dplyr)

tb1<- NEI %>% select(NEI_SCC = SCC,year,Emissions,fips)
tb2<- SCC %>% select(SCC_SCC = SCC,EI.Sector)
final_tb <- inner_join(tb1,tb2,by = c("NEI_SCC" = "SCC_SCC"))

motor2<- final_tb %>%  
  filter(fips %in% c("24510","06037") & EI.Sector %in% c("Mobile - Aircraft","Mobile - Commercial Marine Vessels","Mobile - Locomotives","Mobile - Non-Road Equipment - Diesel","Mobile - Non-Road Equipment - Gasoline","Mobile - Non-Road Equipment - Other","Mobile - On-Road Diesel Heavy Duty Vehicles","Mobile - On-Road Diesel Light Duty Vehicles","Mobile - On-Road Gasoline Heavy Duty Vehicles","Mobile - On-Road Gasoline Light Duty Vehicles"))%>%
  group_by(year,fips)%>% summarise(sum = sum(Emissions,na.rm = T)) %>% transform( fips = factor(fips))

levels(motor2$fips)<- c("Los Angeles County","Baltimore City")

png(filename = "plot6.png")

ggplot(motor2)  + facet_grid(.~fips) + geom_bar(aes(x = as.factor(year),weight = sum) ) +
           labs(x = "year", y ="Total Emissions", title = "Motor Vehicle Emissions, Baltimore City and L.A County, 1999-2008") +
  theme_light()+ theme(plot.title = element_text(hjust = 0.5),strip.text = element_text(color = "black"), strip.background = element_rect(fill = "transparent"))

dev.off()